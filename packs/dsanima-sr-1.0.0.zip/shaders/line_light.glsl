//!DESC dsanima-line-line_light
//!HOOK MAIN
//!BIND HOOKED

#define GAIN 3.50
#define CORING 0.040
#define LINE_DARKEN 0.45
#define LINE_WIDTH 0.70
#define THICKEN 0.25

float lum(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }

vec4 hook() {
    vec4 c = HOOKED_tex(HOOKED_pos);
    float mn = 1.0, mx = 0.0;
    vec4 mnc = c;
    for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
            vec4 s = HOOKED_texOff(vec2(float(i), float(j)));
            float sl = lum(s.rgb);
            mn = min(mn, sl);
            mx = max(mx, sl);
            mnc = min(mnc, s);
        }
    }
    vec4 n = 0.25 * (HOOKED_texOff(vec2( 2.0, 0.0)) + HOOKED_texOff(vec2(-2.0, 0.0))
                   + HOOKED_texOff(vec2( 0.0, 2.0)) + HOOKED_texOff(vec2( 0.0,-2.0)));
    float l = lum(c.rgb);
    float d = l - lum(n.rgb);
    float dc = sign(d) * max(abs(d) - CORING, 0.0);
    float ls = min(l + dc * GAIN, mx);
    float span = max(mx - mn, 1e-3);
    float core = 1.0 - smoothstep(0.0, LINE_WIDTH, (l - mn) / span);
    ls = mix(ls, mn, LINE_DARKEN * core);
    vec3 o = c.rgb * (max(ls, 0.0) / max(l, 1e-4));
    o = mix(o, mnc.rgb, THICKEN * core);   // 线条加粗（只往暗处混）
    return vec4(clamp(o, 0.0, 1.0), c.a);
}
