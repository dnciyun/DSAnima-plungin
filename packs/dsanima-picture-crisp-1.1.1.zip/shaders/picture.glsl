// DSAnima 画面调节包 —— 模板（picture-pack）
//
// 这个文件是**模板**，不是成品 shader：形如 @ + 参数名 + @ 的占位符由宿主的
// 「画面调节」模块按当前滑杆取值替换成数字（本机 libmpv 不认 PARAM，参数只能烧进文本）。
//
// 四条 pass，顺序不能反：
//   1) MAIN 自适应锐化（bacondither Adaptive Sharpen，BSD-3-Clause，
//      逐像素核权重 + tanh 软限幅；curve_height 就是滑杆「锐度」）
//   2) MAIN 线条压暗（只往暗侧压，亮侧不动 → 不起白边）
//   3) MAIN 通透度（局部对比 / 去雾）：片源发灰、像蒙了层雾时往上加
//   4) MAIN 调色（对比/饱和/亮度/gamma/暗部/色温色调）
//
// 每个 pass 开头都有 `if (参数 <= 0.0) return HOOKED_tex(HOOKED_pos);` 这类**常量守卫**：
// 参数是烧进文本的字面量，编译器会把整段死代码删掉 —— 于是「默认 = 初始参数」
// （滑杆全在默认值）时这条链是**真正的原样放过**，不是"算一遍但看起来没变"。
// 用户 2026-10-18 明确要求「默认为初始参数，不是清晰预设」，这一点必须由 shader 保证。
// 锐化放在缩放**之后**（MAIN）：实测曲线 1.0 时 MAIN 与 PREKERNEL 强度相当
// （gradX 0.0220 vs 0.0197），但 MAIN 少了「pre 被缩放器再抹一次」的不确定性。
// 每条 pass 单独编译，`#define` 要写在各自 pass 的指令后面（不要指望跨 pass）。

// ── 1) 锐度：Adaptive Sharpen（bacondither 2020-11-14，BSD-3-Clause）──────────
//!DESC dsanima-picture-1-sharpen
//!HOOK MAIN
//!BIND HOOKED

#define curve_height    @sharpen@
#define overshoot_ctrl  false
#define video_level_out false

#define curveslope      0.5
#define L_overshoot     0.003
#define L_compr_low     0.167
#define L_compr_high    0.334
#define D_overshoot     0.009
#define D_compr_low     0.250
#define D_compr_high    0.500
#define scale_lim       0.1
#define scale_cs        0.056
#define pm_p            0.5

#define max4(a,b,c,d)  ( max(max(a, b), max(c, d)) )
#define soft_if(a,b,c) ( sat((a + b + c + 0.025455)/(maxedge + 0.013636) - 0.85) )
#define soft_lim(v,s)  ( sat(abs(v/s)*(27.0 + pow(v/s, 2.0))/(27.0 + 9.0*pow(v/s, 2.0)))*s )
#define wpmean(a,b,w)  ( pow(w*pow(abs(a), pm_p) + abs(1.0-w)*pow(abs(b), pm_p), (1.0/pm_p)) )
#define get(x,y)       ( sat(HOOKED_texOff(vec2(x, y)).rgb) )
#define sat(x)         ( clamp(x, 0.0, 1.0) )
#define dxdy(val)      ( length(fwidth(val)) )
#define CtL(RGB)       ( dot(RGB*RGB, vec3(0.2126, 0.7152, 0.0722)) )
#define b_diff(pix)    ( abs(blur-c[pix]) )

vec4 hook() {
    // 锐度 0 = 原样放过（判据在文件头：常量折死，不产生真实分支）。
    if (curve_height <= 0.0) return HOOKED_tex(HOOKED_pos);

    vec3 c[25] = vec3[](get( 0, 0), get(-1,-1), get( 0,-1), get( 1,-1), get(-1, 0),
                        get( 1, 0), get(-1, 1), get( 0, 1), get( 1, 1), get( 0,-2),
                        get(-2, 0), get( 2, 0), get( 0, 2), get( 0, 3), get( 1, 2),
                        get(-1, 2), get( 3, 0), get( 2, 1), get( 2,-1), get(-3, 0),
                        get(-2, 1), get(-2,-1), get( 0,-3), get( 1,-2), get(-1,-2));

    float e[13] = float[](dxdy(c[0]),  dxdy(c[1]),  dxdy(c[2]),  dxdy(c[3]),  dxdy(c[4]),
                          dxdy(c[5]),  dxdy(c[6]),  dxdy(c[7]),  dxdy(c[8]),  dxdy(c[9]),
                          dxdy(c[10]), dxdy(c[11]), dxdy(c[12]));

    vec3  blur   = (2.0 * (c[2]+c[4]+c[5]+c[7]) + (c[1]+c[3]+c[6]+c[8]) + 4.0 * c[0]) / 16.0;

    float c_comp = sat(0.266666681f + 0.9*exp2(dot(blur, vec3(-7.4/3.0))));

    float edge = length( 1.38*b_diff(0)
                       + 1.15*(b_diff(2) + b_diff(4) + b_diff(5) + b_diff(7))
                       + 0.92*(b_diff(1) + b_diff(3) + b_diff(6) + b_diff(8))
                       + 0.23*(b_diff(9) + b_diff(10) + b_diff(11) + b_diff(12)) ) * c_comp;

    vec2 cs = vec2(L_compr_low,  D_compr_low);

    if (overshoot_ctrl) {
        float maxedge = max4( max4(e[1],e[2],e[3],e[4]), max4(e[5],e[6],e[7],e[8]),
                              max4(e[9],e[10],e[11],e[12]), e[0] );
        float sbe = soft_if(e[2],e[9], dxdy(c[22]))*soft_if(e[7],e[12],dxdy(c[13]))
                  + soft_if(e[4],e[10],dxdy(c[19]))*soft_if(e[5],e[11],dxdy(c[16]))
                  + soft_if(e[1],dxdy(c[24]),dxdy(c[21]))*soft_if(e[8],dxdy(c[14]),dxdy(c[17]))
                  + soft_if(e[3],dxdy(c[23]),dxdy(c[18]))*soft_if(e[6],dxdy(c[20]),dxdy(c[15]));
        cs = mix(cs, vec2(L_compr_high, D_compr_high), sat(2.4002*sbe - 2.282));
    }

    float luma[25] = float[](CtL(c[0]), CtL(c[1]), CtL(c[2]), CtL(c[3]), CtL(c[4]), CtL(c[5]), CtL(c[6]),
                             CtL(c[7]),  CtL(c[8]),  CtL(c[9]),  CtL(c[10]), CtL(c[11]), CtL(c[12]),
                             CtL(c[13]), CtL(c[14]), CtL(c[15]), CtL(c[16]), CtL(c[17]), CtL(c[18]),
                             CtL(c[19]), CtL(c[20]), CtL(c[21]), CtL(c[22]), CtL(c[23]), CtL(c[24]));

    float c0_Y = sqrt(luma[0]);

    const vec3 w1 = vec3(0.5,           1.0, 1.41421356237);
    const vec3 w2 = vec3(0.86602540378, 1.0, 0.54772255751);

    vec3 dW = pow(mix( w1, w2, sat(2.4*edge - 0.82)), vec3(2.0));

    float modif_e0 = 3.0 * e[0] + 0.0090909;

    float weights[12]  = float[](( min(modif_e0/e[1],  dW.y) ),
                                 ( dW.x ),
                                 ( min(modif_e0/e[3],  dW.y) ),
                                 ( dW.x ),
                                 ( dW.x ),
                                 ( min(modif_e0/e[6],  dW.y) ),
                                 ( dW.x ),
                                 ( min(modif_e0/e[8],  dW.y) ),
                                 ( min(modif_e0/e[9],  dW.z) ),
                                 ( min(modif_e0/e[10], dW.z) ),
                                 ( min(modif_e0/e[11], dW.z) ),
                                 ( min(modif_e0/e[12], dW.z) ));

    weights[0] = (max(max((weights[8]  + weights[9])/4.0,  weights[0]), 0.25) + weights[0])/2.0;
    weights[2] = (max(max((weights[8]  + weights[10])/4.0, weights[2]), 0.25) + weights[2])/2.0;
    weights[5] = (max(max((weights[9]  + weights[11])/4.0, weights[5]), 0.25) + weights[5])/2.0;
    weights[7] = (max(max((weights[10] + weights[11])/4.0, weights[7]), 0.25) + weights[7])/2.0;

    float lowthrsum   = 0.0;
    float weightsum   = 0.0;
    float neg_laplace = 0.0;

    for (int pix = 0; pix < 12; ++pix) {
        float lowthr = clamp((29.04*e[pix + 1] - 0.221), 0.01, 1.0);
        neg_laplace += luma[pix+1] * weights[pix] * lowthr;
        weightsum   += weights[pix] * lowthr;
        lowthrsum   += lowthr / 12.0;
    }

    neg_laplace = inversesqrt(weightsum / neg_laplace);

    float sharpen_val = curve_height/(curve_height*curveslope*pow(edge, 3.5) + 0.625);

    float sharpdiff = (c0_Y - neg_laplace)*(lowthrsum*sharpen_val + 0.01);

    float temp;
    for (int i1 = 0; i1 < 24; i1 += 2) {
        temp = luma[i1];
        luma[i1]   = min(luma[i1], luma[i1+1]);
        luma[i1+1] = max(temp, luma[i1+1]);
    }
    for (int i2 = 24; i2 > 0; i2 -= 2) {
        temp = luma[0];
        luma[0]    = min(luma[0], luma[i2]);
        luma[i2]   = max(temp, luma[i2]);
        temp = luma[24];
        luma[24] = max(luma[24], luma[i2-1]);
        luma[i2-1] = min(temp, luma[i2-1]);
    }
    for (int i1 = 1; i1 < 24-1; i1 += 2) {
        temp = luma[i1];
        luma[i1]   = min(luma[i1], luma[i1+1]);
        luma[i1+1] = max(temp, luma[i1+1]);
    }
    for (int i2 = 24-1; i2 > 1; i2 -= 2) {
        temp = luma[1];
        luma[1]    = min(luma[1], luma[i2]);
        luma[i2]   = max(temp, luma[i2]);
        temp = luma[24-1];
        luma[24-1] = max(luma[24-1], luma[i2-1]);
        luma[i2-1] = min(temp, luma[i2-1]);
    }

    float nmax = (max(sqrt(luma[23]), c0_Y)*2.0 + sqrt(luma[24]))/3.0;
    float nmin = (min(sqrt(luma[1]),  c0_Y)*2.0 + sqrt(luma[0]))/3.0;

    float min_dist  = min(abs(nmax - c0_Y), abs(c0_Y - nmin));
    float pos_scale = min_dist + L_overshoot;
    float neg_scale = min_dist + D_overshoot;

    pos_scale = min(pos_scale, scale_lim*(1.0 - scale_cs) + pos_scale*scale_cs);
    neg_scale = min(neg_scale, scale_lim*(1.0 - scale_cs) + neg_scale*scale_cs);

    sharpdiff = wpmean(max(sharpdiff, 0.0), soft_lim( max(sharpdiff, 0.0), pos_scale ), cs.x )
              - wpmean(min(sharpdiff, 0.0), soft_lim( min(sharpdiff, 0.0), neg_scale ), cs.y );

    float sharpdiff_lim = sat(c0_Y + sharpdiff) - c0_Y;
    float satmul = (c0_Y + max(sharpdiff_lim*0.9, sharpdiff_lim)*1.03 + 0.03)/(c0_Y + 0.03);
    vec3 res = c0_Y + (sharpdiff_lim*3.0 + sharpdiff)/4.0 + (c[0] - c0_Y)*satmul;

    return vec4(video_level_out == true ? res + HOOKED_texOff(0).rgb - c[0] : res, HOOKED_texOff(0).a);
}

// ── 2) 线条：单向锐化 + 只往暗侧压 ─────────────────────────────────────────
//!DESC dsanima-picture-2-line
//!HOOK MAIN
//!BIND HOOKED

#define LINE @line@
#define GAIN 3.50
#define CORING 0.040

float lum2(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }

vec4 hook() {
    // 线条 0 = 原样放过。注意**不能**靠后面的 mix(…, LINE*core) 来"关"：
    // 那一行之前已经 `ls = min(l + dc*GAIN, mx)` 做过一次单向锐化了，
    // 只把 LINE 置 0 会剩下"只压暗侧的锐化"—— 那不是"关"。
    if (LINE <= 0.0) return HOOKED_tex(HOOKED_pos);

    vec4 c = HOOKED_tex(HOOKED_pos);
    float mn = 1.0, mx = 0.0;
    vec4 mnc = c;
    for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
            vec4 s = HOOKED_texOff(vec2(float(i), float(j)));
            float sl = lum2(s.rgb);
            mn = min(mn, sl);
            mx = max(mx, sl);
            mnc = min(mnc, s);
        }
    }
    // 半径 2 的十字平均：只跟"隔一个像素"的邻居比，避开 8bit 抖动
    vec4 n = 0.25 * (HOOKED_texOff(vec2( 2.0, 0.0)) + HOOKED_texOff(vec2(-2.0, 0.0))
                   + HOOKED_texOff(vec2( 0.0, 2.0)) + HOOKED_texOff(vec2( 0.0,-2.0)));
    float l = lum2(c.rgb);
    float d = l - lum2(n.rgb);
    // coring：平坦区不动。然后**夹到局部最大值**——这是"单向"的含义：
    // 只允许把暗的压更暗，不许把亮的推更亮，所以白侧永远不会起 halo。
    float dc = sign(d) * max(abs(d) - CORING, 0.0);
    float ls = min(l + dc * GAIN, mx);
    float span = max(mx - mn, 1e-3);
    // 线心判定：越接近局部最暗越算线
    float core = 1.0 - smoothstep(0.0, 0.70, (l - mn) / span);
    ls = mix(ls, mn, LINE * core);
    vec3 o = c.rgb * (max(ls, 0.0) / max(l, 1e-4));
    // 轻微加粗（只往更暗的邻域颜色混），厚度随 LINE 一起变
    o = mix(o, mnc.rgb, clamp(LINE * 0.55, 0.0, 0.5) * core);
    return vec4(clamp(o, 0.0, 1.0), c.a);
}

// ── 3) 通透度：局部对比 / 去雾 ───────────────────────────────────────────────
//!DESC dsanima-picture-3-clarity
//!HOOK MAIN
//!BIND HOOKED
//
// 干什么：片源"蒙了层雾 / 黑不够黑 / 泛白"时，把**局部**对比拉回来。
// 为什么不用全局对比度解决：全局对比是围绕中灰拉，会把高光一起推爆、暗部压死；
// 发灰的片子缺的是"这一小块比周围该亮/该暗多少"，所以取一个半径 3px 的十字平均当
// 局部背景，只放大"当前像素与它的差"。半径不是随手写的：2~4px 正好是压缩噪声与
// 雾状晕开的尺度，再大就变成"清晰度"效果（会开始出现白边）。
//
// 两条保护：
//   * coring：差小于 CORING 的地方不动（平坦区/噪声不放大，不给画面加颗粒）；
//   * 强差处收力：局部差越大越可能是真正的线/边，放大它只会起白边，所以按 |d| 衰减。
// CLARITY = 0 时整段折死（见文件头的常量守卫）。

#define CLARITY @clarity@
#define TL_RADIUS 3.0
#define TL_CORING 0.020

float tl_luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }

vec4 hook() {
    if (CLARITY <= 0.0) return HOOKED_tex(HOOKED_pos);

    vec4 c = HOOKED_tex(HOOKED_pos);
    vec4 blur = 0.25 * (HOOKED_texOff(vec2( TL_RADIUS, 0.0)) + HOOKED_texOff(vec2(-TL_RADIUS, 0.0))
                      + HOOKED_texOff(vec2(0.0,  TL_RADIUS)) + HOOKED_texOff(vec2(0.0, -TL_RADIUS)));
    float l = tl_luma(c.rgb);
    float d = l - tl_luma(blur.rgb);
    // coring：符号保留、幅度减掉噪声门限
    d = sign(d) * max(abs(d) - TL_CORING, 0.0);
    // 强差收力（0.10 以下全给，0.35 以上基本不给）
    float amp = CLARITY * 0.55 * (1.0 - smoothstep(0.10, 0.35, abs(d)));
    float target = clamp(l + d * amp, 0.0, 1.0);
    // 按亮度比例缩 RGB（保住色相），而不是给三个通道各自加减
    vec3 o = c.rgb * (target / max(l, 1e-4));
    return vec4(clamp(o, 0.0, 1.0), c.a);
}

// ── 4) 调色：对比/饱和/亮度/gamma/暗部/色温色调 ─────────────────────────────
//!DESC dsanima-picture-4-grade
//!HOOK MAIN
//!BIND HOOKED

#define CONTRAST    @contrast@
#define SATURATION  @saturation@
#define BRIGHTNESS  @brightness@
#define GAMMA       @gamma@
#define DARK_LIFT   @dark_lift@
#define TEMPERATURE @temperature@
#define TINT        @tint@

vec4 hook() {
    vec4 src = HOOKED_tex(HOOKED_pos);
    vec3 c = src.rgb;

    // gamma（>1 提亮中间调，<1 压暗）
    c = pow(max(c, 0.0), vec3(1.0 / max(GAMMA, 0.01)));
    // 亮度（线性偏移）
    c += vec3(BRIGHTNESS);
    // 暗部提升：只抬暗处，权重 (1-luma)^2 —— 不把白的地方也洗掉
    float l = dot(c, vec3(0.299, 0.587, 0.114));
    float dark = (1.0 - clamp(l, 0.0, 1.0));
    c += vec3(DARK_LIFT * dark * dark);
    // 对比（围绕中灰）
    c = (c - 0.5) * CONTRAST + 0.5;
    // 饱和（围绕自身的 luma）
    float g = dot(c, vec3(0.299, 0.587, 0.114));
    c = mix(vec3(g), c, SATURATION);
    // 色温/色调：暖 = 红上蓝下；tint 正 = 偏绿
    c += vec3(TEMPERATURE, TINT, -TEMPERATURE);

    return vec4(clamp(c, 0.0, 1.0), src.a);
}
