// dsanima-picture —— 合并版「画面调节」模板（单 pass，参数由宿主按 preset 渲染成常量）
//
// ⚠️ 为什么所有效果都塞在一个 hook() 里：mpv 的 user shader **一个文件只算一个 pass**
// （实测：把 #error 放进第二个 //!DESC 块不会报错，放进第一个才报）。旧包
// dsanima-picture-crisp 的模板写了 4 个 //!DESC 块，实际只有第一段（锐化）在跑，
// 线条/通透/调色三段是死代码。这一版把它们合进同一个 pass。
//
// 代价：多 pass 链里后一段看到的是前一段的输出，单 pass 只有原始帧。所以这里的做法是
// 「所有效果都基于原始邻域样本计算，再按顺序叠加到中心像素」，观感接近但不是逐段合成。
//
// 计算顺序：降噪 → 锐化 → 通透 → 线条 → 去色带 → 调色（与面板分组一致）
//!DESC dsanima-picture
//!HOOK MAIN
//!BIND HOOKED

#define SHARPEN     @sharpen@
#define LINE        @line@
#define CLARITY     @clarity@
#define CONTRAST    @contrast@
#define SATURATION  @saturation@
#define BRIGHTNESS  @brightness@
#define GAMMA       @gamma@
#define DARK_LIFT   @dark_lift@
#define TEMPERATURE @temperature@
#define TINT        @tint@
#define DEBAND      @deband@
#define DENOISE     @denoise@

float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }

vec4 hook() {
    vec4 c  = HOOKED_tex(HOOKED_pos);
    vec4 n1 = HOOKED_texOff(vec2( 1.0,  0.0));
    vec4 n2 = HOOKED_texOff(vec2(-1.0,  0.0));
    vec4 n3 = HOOKED_texOff(vec2( 0.0,  1.0));
    vec4 n4 = HOOKED_texOff(vec2( 0.0, -1.0));
    vec4 d1 = HOOKED_texOff(vec2( 1.0,  1.0));
    vec4 d2 = HOOKED_texOff(vec2(-1.0,  1.0));
    vec4 d3 = HOOKED_texOff(vec2( 1.0, -1.0));
    vec4 d4 = HOOKED_texOff(vec2(-1.0, -1.0));
    vec4 f1 = HOOKED_texOff(vec2( 2.0,  0.0));
    vec4 f2 = HOOKED_texOff(vec2(-2.0,  0.0));
    vec4 f3 = HOOKED_texOff(vec2( 0.0,  2.0));
    vec4 f4 = HOOKED_texOff(vec2( 0.0, -2.0));

    vec4 blur3 = (n1 + n2 + n3 + n4 + d1 + d2 + d3 + d4) * 0.125;   // 3x3 盒式模糊
    vec4 far   = (f1 + f2 + f3 + f4) * 0.25;                        // 半径 2 十字

    float l  = luma(c.rgb);
    float lm = min(min(min(luma(n1.rgb), luma(n2.rgb)), min(luma(n3.rgb), luma(n4.rgb))), l);
    float lx = max(max(max(luma(n1.rgb), luma(n2.rgb)), max(luma(n3.rgb), luma(n4.rgb))), l);
    float span = max(lx - lm, 1e-3);
    float edge = smoothstep(0.015, 0.20, span);                     // 平坦区不动，避免放大噪点
    vec4  mnc  = min(min(min(n1, n2), min(n3, n4)), c);             // 邻域最暗（线条加粗用）

    // ① 降噪：边缘保持（权重按亮度差），只在 DE NOISE>0 时有开销效果
    if (DENOISE > 0.001) {
        float w0 = 1.0;
        float w1 = exp(-abs(luma(n1.rgb) - l) * 20.0);
        float w2 = exp(-abs(luma(n2.rgb) - l) * 20.0);
        float w3 = exp(-abs(luma(n3.rgb) - l) * 20.0);
        float w4 = exp(-abs(luma(n4.rgb) - l) * 20.0);
        float wd = 0.35 * (exp(-abs(luma(d1.rgb) - l) * 20.0) + exp(-abs(luma(d2.rgb) - l) * 20.0)
                         + exp(-abs(luma(d3.rgb) - l) * 20.0) + exp(-abs(luma(d4.rgb) - l) * 20.0));
        vec4 sum = c * w0 + n1 * w1 + n2 * w2 + n3 * w3 + n4 * w4
                 + (d1 + d2 + d3 + d4) * (wd * 0.25);
        float wsum = w0 + w1 + w2 + w3 + w4 + wd;
        c = mix(c, sum / max(wsum, 1e-4), DENOISE);
    }

    // ② 锐化：半径 2 的十字为基准，只在有明显边缘处加，系数压低防白边
    c.rgb += (c.rgb - far.rgb) * SHARPEN * edge * 0.5;

    // ③ 通透：中低频局部对比（暗部/雾感更吃这一项）
    float midtone = 1.0 - abs(luma(c.rgb) - 0.5) * 1.6;
    c.rgb += (c.rgb - far.rgb) * CLARITY * clamp(midtone, 0.0, 1.0) * 0.5;

    // ④ 线条：压暗暗侧 + 轻微加粗（单向，只往暗处混，不起白边）
    if (LINE > 0.001) {
        float l2 = luma(c.rgb);
        float core = 1.0 - smoothstep(0.0, 0.70, (l2 - lm) / span);
        vec3 mixed = mix(c.rgb, mnc.rgb, LINE * core * 0.35);
        float target = mix(l2, lm, LINE * core);
        c.rgb = mixed * (target / max(l2, 1e-4));
    }

    // ⑤ 去色带：局部范围很小时把梯度压平一点，再加 1/255 的抖动打散边界
    if (DEBAND > 0.001) {
        float flatness = 1.0 - smoothstep(0.004, 0.05, span);
        vec2 px = HOOKED_pos / max(HOOKED_pt, vec2(1e-6));
        float dith = fract(sin(dot(floor(px), vec2(12.9898, 78.233))) * 43758.5453);
        vec3 smoothc = mix(c.rgb, blur3.rgb, 0.6) + (dith - 0.5) / 255.0;
        c.rgb = mix(c.rgb, smoothc, DEBAND * flatness);
    }

    // ⑥ 调色：对比 → 亮度 → 伽马 → 暗部提升 → 色温/色调 → 饱和
    c.rgb = (c.rgb - 0.5) * CONTRAST + 0.5;
    c.rgb += BRIGHTNESS;
    c.rgb = pow(clamp(c.rgb, 0.0, 1.0), vec3(1.0 / max(GAMMA, 1e-3)));
    float lg = luma(c.rgb);
    c.rgb += DARK_LIFT * (1.0 - smoothstep(0.0, 0.55, lg));
    c.rgb += vec3(TEMPERATURE, TINT * 0.5, -TEMPERATURE);
    float ls = luma(c.rgb);
    c.rgb = mix(vec3(ls), c.rgb, SATURATION);

    return vec4(clamp(c.rgb, 0.0, 1.0), c.a);
}
